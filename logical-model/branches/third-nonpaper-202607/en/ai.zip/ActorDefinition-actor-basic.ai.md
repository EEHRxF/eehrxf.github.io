# Basic - EHDS Logical Information Models v0.1.0

## ActorDefinition: Basic 



## Resource Content

```json
{
  "resourceType" : "ActorDefinition",
  "id" : "actor-basic",
  "url" : "https://ehds.eu/specifications/fhir/actor-basic",
  "version" : "0.1.0",
  "name" : "Basic",
  "status" : "active",
  "date" : "2026-09-10T06:54:27+00:00",
  "publisher" : "EC",
  "contact" : [{
    "name" : "EC",
    "telecom" : [{
      "system" : "url",
      "value" : "http://commission.europa.eu/"
    }]
  }],
  "type" : "system"
}

```
