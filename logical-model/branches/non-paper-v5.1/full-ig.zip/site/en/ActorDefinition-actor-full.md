# Full - EHDS Logical Information Models v0.3.0

## ActorDefinition: Full 



## Resource Content

```json
{
  "resourceType" : "ActorDefinition",
  "id" : "actor-full",
  "url" : "https://ehds.eu/specifications/fhir/actor-full",
  "version" : "0.3.0",
  "name" : "Full",
  "status" : "active",
  "date" : "2026-11-20T06:54:54+00:00",
  "publisher" : "EC",
  "contact" : [{
    "name" : "EC",
    "telecom" : [{
      "system" : "url",
      "value" : "http://commission.europa.eu/"
    }]
  }],
  "type" : "system"
}

```
